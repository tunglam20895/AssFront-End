import React from 'react'

const index = () => {
    return (
        <div>
            <a href="https://nicepage.com" className="u-image u-logo u-image-1">
                <img src="images/default-logo.png" className="u-logo-image u-logo-image-1" />
            </a>
            <nav className="u-menu u-menu-dropdown u-offcanvas u-menu-1">
                <div className="menu-collapse" style={{ fontSize: '1rem', letterSpacing: '0px' }}>
                    <a className="u-button-style u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="#">
                        <svg><use xmlnsXlink="http://www.w3.org/1999/xlink" xlinkHref="#menu-hamburger" /></svg>
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink"><defs><symbol id="menu-hamburger" viewBox="0 0 16 16" style={{ width: '16px', height: '16px' }}><rect y={1} width={16} height={2} /><rect y={7} width={16} height={2} /><rect y={13} width={16} height={2} />
                        </symbol>
                        </defs></svg>
                    </a>
                </div>
                <div className="u-nav-container">
                    <ul className="u-nav u-unstyled u-nav-1"><li className="u-nav-item"><a className="u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base" href="Page-1.html" style={{ padding: '10px 20px' }}>Page 1</a>
                    </li></ul>
                </div>
                <div className="u-nav-container-collapse">
                    <div className="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
                        <div className="u-sidenav-overflow">
                            <div className="u-menu-close" />
                            <ul className="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li className="u-nav-item"><a className="u-button-style u-nav-link" href="Page-1.html">Page 1</a>
                            </li></ul>
                        </div>
                    </div>
                    <div className="u-black u-menu-overlay u-opacity u-opacity-70" />
                </div>
            </nav>
            <section className="u-clearfix u-grey-5 u-section-1" id="carousel_4d68">
                <div className="u-clearfix u-sheet u-valign-middle u-sheet-1">
                    <h2 className="u-text u-text-default u-text-1">Let's Connect</h2>
                    <div className="u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
                        <div className="u-layout">
                            <div className="u-layout-col">
                                <div className="u-size-30">
                                    <div className="u-layout-row">
                                        <div className="u-align-center u-container-style u-layout-cell u-left-cell u-size-15 u-size-30-md u-layout-cell-1">
                                            <div className="u-container-layout u-container-layout-1"><span className="u-icon u-icon-circle u-text-grey-40 u-icon-1"><svg className="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style={{}}><use xmlnsXlink="http://www.w3.org/1999/xlink" xlinkHref="#svg-fb01" /></svg><svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" version="1.1" id="svg-fb01" x="0px" y="0px" viewBox="0 0 512 512" style={{ enableBackground: 'new 0 0 512 512' }} xmlSpace="preserve" className="u-svg-content"><g><g><path d="M256,0C153.755,0,70.573,83.182,70.573,185.426c0,126.888,165.939,313.167,173.004,321.035    c6.636,7.391,18.222,7.378,24.846,0c7.065-7.868,173.004-194.147,173.004-321.035C441.425,83.182,358.244,0,256,0z M256,278.719    c-51.442,0-93.292-41.851-93.292-93.293S204.559,92.134,256,92.134s93.291,41.851,93.291,93.293S307.441,278.719,256,278.719z" />
                                            </g>
                                            </g><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /></svg></span>
                                                <h6 className="u-text u-text-default u-text-2">OUR MAIN OFFICE</h6>
                                                <p className="u-text u-text-default u-text-3">SoHo 94 Broadway St&nbsp;New York, NY 1001</p>
                                            </div>
                                        </div>
                                        <div className="u-align-center-lg u-align-center-md u-align-center-sm u-align-center-xs u-container-style u-layout-cell u-size-15 u-size-30-md u-layout-cell-2">
                                            <div className="u-container-layout u-valign-top-lg u-valign-top-xl u-container-layout-2"><span className="u-icon u-icon-circle u-text-grey-40 u-icon-2"><svg className="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 384 384" style={{}}><use xmlnsXlink="http://www.w3.org/1999/xlink" xlinkHref="#svg-cd86" /></svg><svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" version="1.1" id="svg-cd86" x="0px" y="0px" viewBox="0 0 384 384" style={{ enableBackground: 'new 0 0 384 384' }} xmlSpace="preserve" className="u-svg-content"><g><g><path d="M353.188,252.052c-23.51,0-46.594-3.677-68.469-10.906c-10.719-3.656-23.896-0.302-30.438,6.417l-43.177,32.594    c-50.073-26.729-80.917-57.563-107.281-107.26l31.635-42.052c8.219-8.208,11.167-20.198,7.635-31.448    c-7.26-21.99-10.948-45.063-10.948-68.583C132.146,13.823,118.323,0,101.333,0H30.813C13.823,0,0,13.823,0,30.813    C0,225.563,158.438,384,353.188,384c16.99,0,30.813-13.823,30.813-30.813v-70.323C384,265.875,370.177,252.052,353.188,252.052z" />
                                            </g>
                                            </g><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /></svg></span>
                                                <h6 className="u-align-center-xl u-text u-text-default u-text-4">phone number</h6>
                                                <p className="u-align-center-xl u-text u-text-default u-text-5">234-9876-5400<br />888-0123-4567 (Toll Free)
                    </p>
                                            </div>
                                        </div>
                                        <div className="u-align-center-md u-align-center-sm u-align-center-xs u-container-style u-layout-cell u-size-15 u-size-30-md u-layout-cell-3">
                                            <div className="u-container-layout u-valign-top u-container-layout-3"><span className="u-icon u-icon-circle u-text-grey-40 u-icon-3"><svg className="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style={{}}><use xmlnsXlink="http://www.w3.org/1999/xlink" xlinkHref="#svg-f872" /></svg><svg xmlns="http://www.w3.org/2000/svg" id="svg-f872" enableBackground="new 0 0 512 512" viewBox="0 0 512 512" className="u-svg-content"><path d="m201 12.714v184.286h267v-184.286c0-7.022-5.692-12.714-12.714-12.714h-241.572c-7.022 0-12.714 5.692-12.714 12.714zm63.89 33.131h70.271c8.284 0 15 6.716 15 15s-6.716 15-15 15h-70.271c-8.284 0-15-6.716-15-15s6.715-15 15-15zm0 75.142h139.22c8.284 0 15 6.716 15 15s-6.716 15-15 15h-139.22c-8.284 0-15-6.716-15-15s6.715-15 15-15z" /><path d="m472 227h-275c-22.091 0-40 17.909-40 40v205c0 22.091 17.909 40 40 40h275c22.091 0 40-17.909 40-40v-205c0-22.091-17.909-40-40-40zm-207.5 217.5h-20c-8.284 0-15-6.716-15-15s6.716-15 15-15h20c8.284 0 15 6.716 15 15s-6.716 15-15 15zm0-60h-20c-8.284 0-15-6.716-15-15s6.716-15 15-15h20c8.284 0 15 6.716 15 15s-6.716 15-15 15zm0-60h-20c-8.284 0-15-6.716-15-15s6.716-15 15-15h20c8.284 0 15 6.716 15 15s-6.716 15-15 15zm80 120h-20c-8.284 0-15-6.716-15-15s6.716-15 15-15h20c8.284 0 15 6.716 15 15s-6.716 15-15 15zm0-60h-20c-8.284 0-15-6.716-15-15s6.716-15 15-15h20c8.284 0 15 6.716 15 15s-6.716 15-15 15zm0-60h-20c-8.284 0-15-6.716-15-15s6.716-15 15-15h20c8.284 0 15 6.716 15 15s-6.716 15-15 15zm80 120h-20c-8.284 0-15-6.716-15-15s6.716-15 15-15h20c8.284 0 15 6.716 15 15s-6.716 15-15 15zm0-60h-20c-8.284 0-15-6.716-15-15s6.716-15 15-15h20c8.284 0 15 6.716 15 15s-6.716 15-15 15zm0-60h-20c-8.284 0-15-6.716-15-15s6.716-15 15-15h20c8.284 0 15 6.716 15 15s-6.716 15-15 15z" /><path d="m87 227h-47c-22.091 0-40 17.909-40 40v205c0 22.091 17.909 40 40 40h47c22.091 0 40-17.909 40-40v-205c0-22.091-17.909-40-40-40z" /></svg></span>
                                                <h6 className="u-align-center-lg u-align-center-xl u-text u-text-default u-text-6">fax</h6>
                                                <p className="u-align-center-lg u-align-center-xl u-text u-text-default u-text-7">1-234-567-8900</p>
                                            </div>
                                        </div>
                                        <div className="u-align-center-lg u-align-center-md u-align-center-sm u-align-center-xs u-container-style u-layout-cell u-right-cell u-size-15 u-size-30-md u-layout-cell-4">
                                            <div className="u-container-layout u-valign-top u-container-layout-4"><span className="u-icon u-icon-circle u-text-grey-40 u-icon-4"><svg className="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style={{}}><use xmlnsXlink="http://www.w3.org/1999/xlink" xlinkHref="#svg-d2c4" /></svg><svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" version="1.1" id="svg-d2c4" x="0px" y="0px" viewBox="0 0 512 512" style={{ enableBackground: 'new 0 0 512 512' }} xmlSpace="preserve" className="u-svg-content"><g><g><path d="M467,61H45c-6.927,0-13.412,1.703-19.279,4.51L255,294.789l51.389-49.387c0,0,0.004-0.005,0.005-0.007    c0.001-0.002,0.005-0.004,0.005-0.004L486.286,65.514C480.418,62.705,473.929,61,467,61z" />
                                            </g>
                                            </g><g><g><path d="M507.496,86.728L338.213,256.002L507.49,425.279c2.807-5.867,4.51-12.352,4.51-19.279V106    C512,99.077,510.301,92.593,507.496,86.728z" />
                                            </g>
                                                </g><g><g><path d="M4.51,86.721C1.703,92.588,0,99.073,0,106v300c0,6.923,1.701,13.409,4.506,19.274L173.789,256L4.51,86.721z" />
                                                </g>
                                                </g><g><g><path d="M317.002,277.213l-51.396,49.393c-2.93,2.93-6.768,4.395-10.605,4.395s-7.676-1.465-10.605-4.395L195,277.211    L25.714,446.486C31.582,449.295,38.071,451,45,451h422c6.927,0,13.412-1.703,19.279-4.51L317.002,277.213z" />
                                                </g>
                                                </g><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /><g /></svg></span>
                                                <h6 className="u-align-center-xl u-text u-text-default u-text-8">mail</h6>
                                                <p className="u-align-center-xl u-text u-text-default u-text-9">hello@theme.com</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="u-size-30">
                                    <div className="u-layout-row">
                                        <div className="u-size-30">
                                            <div className="u-layout-col">
                                                <div className="u-container-style u-layout-cell u-left-cell u-size-60 u-layout-cell-5">
                                                    <div className="u-container-layout u-container-layout-5">
                                                        <h3 className="u-text u-text-default u-text-10">Get a free case evaluation today!</h3>
                                                        <h6 className="u-text u-text-default u-text-11">AVAILABLE 24 HOURS A DAY!</h6>
                                                        <div className="u-form u-form-1">
                                                            <form action="#" method="POST" className="u-clearfix u-form-spacing-10 u-form-vertical u-inner-form" style={{ padding: 0 }} source="custom" name="form">
                                                                <div className="u-form-group u-form-name">
                                                                    <label htmlFor="name-3d90" className="u-form-control-hidden u-label">Name</label>
                                                                    <input type="text" placeholder="Enter your Name" id="name-3d90" name="name" className="u-input u-input-rectangle u-white" required />
                                                                </div>
                                                                <div className="u-form-email u-form-group">
                                                                    <label htmlFor="email-3d90" className="u-form-control-hidden u-label">Email</label>
                                                                    <input type="email" placeholder="Enter a valid email address" id="email-3d90" name="email" className="u-input u-input-rectangle u-white" required />
                                                                </div>
                                                                <div className="u-form-group u-form-message">
                                                                    <label htmlFor="message-3d90" className="u-form-control-hidden u-label">Message</label>
                                                                    <textarea placeholder="Enter your message" rows={4} cols={50} id="message-3d90" name="message" className="u-input u-input-rectangle u-white" required defaultValue={""} />
                                                                </div>
                                                                <div className="u-align-left u-form-group u-form-submit">
                                                                    <a href="#" className="u-border-2 u-border-grey-dark-1 u-btn u-btn-rectangle u-btn-submit u-button-style u-none u-btn-1">Submit</a>
                                                                    <input type="submit" defaultValue="submit" className="u-form-control-hidden" />
                                                                </div>
                                                                <div className="u-form-send-message u-form-send-success"> Thank you! Your message has been sent. </div>
                                                                <div className="u-form-send-error u-form-send-message"> Unable to send your message. Please fix errors then try again. </div>
                                                                <input type="hidden" defaultValue name="recaptchaResponse" />
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="u-size-30">
                                            <div className="u-layout-col">
                                                <div className="u-container-style u-layout-cell u-right-cell u-size-60 u-layout-cell-6">
                                                    <div className="u-container-layout u-container-layout-6">
                                                        <h3 className="u-text u-text-default u-text-12">we are here</h3>
                                                        <h6 className="u-text u-text-default u-text-13">Mon-Fri 8:30am- 5pm / Phones are open 24/7</h6>
                                                        <div className="u-grey-light-2 u-map u-map-1">
                                                            <div className="embed-responsive">
                                                                <iframe className="embed-responsive-item" src="//maps.google.com/maps?output=embed&q=Manhattan%2C%20New%20York&z=10&t=m" data-map="JTdCJTIyYWRkcmVzcyUyMiUzQSUyMk1hbmhhdHRhbiUyQyUyME5ldyUyMFlvcmslMjIlMkMlMjJ6b29tJTIyJTNBMTAlMkMlMjJ0eXBlSWQlMjIlM0ElMjJyb2FkJTIyJTJDJTIybGFuZyUyMiUzQSUyMiUyMiU3RA==" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <footer className="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-07b9"><div className="u-clearfix u-sheet u-sheet-1">
                <p className="u-small-text u-text u-text-variant u-text-1">Sample text. Click to select the text box. Click again or double click to start editing the text.</p>
            </div></footer>
            <section className="u-backlink u-clearfix u-grey-80">
                <a className="u-link" href="https://nicepage.com/website-templates" target="_blank">
                    <span>Website Templates</span>
                </a>
                <p className="u-text">
                    <span>created with</span>
                </p>
                <a className="u-link" href="https://nicepage.com/" target="_blank">
                    <span>Website Builder Software</span>
                </a>.
  </section>
        </div>

    )
}

export default index
